<?php
/**
 * @author JoomlaShine.com Team
 * @copyright JoomlaShine.com
 * @link joomlashine.com
 * @package JSN ImageShow
 * @version $Id: defines.php 6751 2011-06-15 07:54:47Z giangnd $
 * @license GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die('Restricted access');
define('AUTOUPDATE_LINK', 'http://www.joomlashine.com/index.php?option=com_lightcart&controller=remoteauthentication&task=authenticate&tmpl=component');
define('CHECKUPDATE_LINK', 'http://www.joomlashine.com/index.php?option=com_lightcart&controller=productversioninfo&task=getinfo&tmpl=component');